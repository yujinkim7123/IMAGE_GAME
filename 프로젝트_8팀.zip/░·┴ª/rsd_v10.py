import os
import cv2
import mediapipe as mp
import numpy as np
import time
import pandas as pd

max_num_hands = 2
gesture = {
    0:'fist', 1:'one', 2:'two', 3:'three', 4:'four', 5:'five',
    6:'six', 7:'rock', 8:'spiderman', 9:'yeah', 10:'ok',
}
rps_gesture = {0:'rock', 5:'paper', 9:'scissors'}

# MediaPipe hands model
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    max_num_hands=max_num_hands,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5)

# Gesture recognition model
knn = cv2.ml.KNearest_load("./train.xml")

#start img_org loadingfr
image = cv2.imread("./start_img_sample.jfif", cv2.IMREAD_ANYCOLOR)
is_start = True


#crmera setup
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_BUFFERSIZE,1)
# cap.set(cv2.CAP_PROP_FPS, 15)
result_dir = "./result"
v = 1

#dir make(model _train_set)
while True:
    dir = os.path.join(result_dir, "v" + str(v))
    if not os.path.exists(dir):
        result_dir = dir
        os.makedirs(result_dir)
        break
    v += 1

result_dic = {}
for c in ["success", "fail", "no_cls"]:
    dir = os.path.join(result_dir, c)
    os.makedirs(dir)
    result_dic[c] = dir
i = 0

global img_org
global stop
global right_person, left_person
right_person = 0
left_person = 0
stop = False


columns = ["p1", "p2", "sfn"]
rs_ratio = 0.5
font_size = 1

while cap.isOpened():
  
  if is_start: 
    image = cv2.resize(image, dsize=(500,500))
    cv2.imshow("start_img", image) 
    k = cv2.waitKey() # enter push and start
    if k == ord('q'):
       stop = True
       break
    cv2.destroyAllWindows()
    is_start = False #start so change key
 
  is_game_start = True     
    #wait game start     
  while is_game_start:
    ret, img = cap.read()

    height = int(img.shape[1]/2)
    wight = int(img.shape[0])

    img = cv2.flip(img, 1)
    #img = cv2.resize(img, None, fx=rs_ratio, fy=rs_ratio, interpolation=cv2.INTER_AREA)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    fps = cap.get(cv2.CAP_PROP_FPS)
    delay = int(1000/fps)

    cv2.line(img, (height,0), (height, wight), (100,0,0), 3)
    cv2.putText(img, "Press s to start the game.", org=(int(img.shape[1] / 6.5), 60), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(0, 0, 255), thickness=3)
    
    cv2.imshow('Game',  img)

    k = cv2.waitKey(delay)

    if k == ord('q'):
      stop = True
      break
    if k == ord('s'):
      is_game_start = False
      break
          
  if stop == True:
     break      
  
    #start game img_org read and timer start
  is_end_timer = True
  pre_time = time.time()
  counter = 3
  # print("clike")  

  while is_end_timer:
    ret, img = cap.read()      
    after_time = time.time()

    img = cv2.flip(img, 1)
    img_org = img

    if not ret:
      continue
      
    if counter == 0:
      is_end_timer = False
      break  
    
    fps = cap.get(cv2.CAP_PROP_FPS)
    delay = int(1000/fps)

    # img = cv2.flip(img, 1)
    img = cv2.resize(img, None, fx=rs_ratio, fy=rs_ratio, interpolation=cv2.INTER_AREA)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) 
    # img = cv2.blur(img, (2, 2))

    height = int(img.shape[1]/2)
    wight = int(img.shape[0])
    cv2.line(img, (height,0), (height, wight), (100,0,0), 3)
    cv2.putText(img, str(counter), org=(int(img.shape[1] / 6.5), 60), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=2, color=(0, 0, 255), thickness=3)
    cv2.imshow('Game', img)

    if abs(pre_time - after_time) >= 1:
      counter = counter - 1
      pre_time = after_time

    # print("clike")  
    cv2.waitKey(delay) 
      
  img_org = cv2.cvtColor(img_org, cv2.COLOR_BGR2RGB)  
  result = hands.process(img_org)

  img_org = cv2.cvtColor(img_org, cv2.COLOR_RGB2BGR)  
  # cv2.imshow('Game', img_org)
  # cv2.waitKey() 
  ######clean code


  if result.multi_hand_landmarks is not None and len(result.multi_hand_landmarks) > 1:
    rps_result = []
    indices = []
    
    for res in result.multi_hand_landmarks:
        joint = np.zeros((21, 3))
        for j, lm in enumerate(res.landmark):
            joint[j] = [lm.x, lm.y, lm.z]
        # Compute angles between joints
        v1 = joint[[0,1,2,3,0,5,6,7,0,9,10,11,0,13,14,15,0,17,18,19],:] # Parent joint
        v2 = joint[[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],:] # Child joint
        v = v2 - v1 # [20,3]
            # Normalize v
        v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]

        # Get angle using arcos of dot product
        angle = np.arccos(np.einsum('nt,nt->n',
            v[[0,1,2,4,5,6,8,9,10,12,13,14,16,17,18],:], 
            v[[1,2,3,5,6,7,9,10,11,13,14,15,17,18,19],:])) # [15,]

        angle = np.degrees(angle) # Convert radian to degree

        # Inference gesture
        data = np.array([angle], dtype=np.float32)
        ret, results, neighbours, dist = knn.findNearest(data, 3)
            
        idx = int(results[0][0])
            
        # Draw gesture result
        if idx in rps_gesture.keys():
            indices.append(idx)
            org = (int(res.landmark[0].x * img_org.shape[1]), int(res.landmark[0].y * img_org.shape[0]))
            # rock scissor paper 
            # cv2.putText(img_org, text=rps_gesture[idx].upper(), org=(org[0], org[1] + 20), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
            rps_result.append({
                    'rps': rps_gesture[idx],
                    'org': org
                })
    rps_result.sort(key=lambda x: x['org'][0])
    if len(rps_result) >= 2:
        winner = None
        tie = False
        text = ''
        cls_text = "if right press r, f for fail"

        if rps_result[0]['rps']=='rock':
            if rps_result[1]['rps']=='rock'     : text = 'Tie' ; tie = True
            elif rps_result[1]['rps']=='paper'  : text = 'Paper wins'  ; winner = 1; right_person = right_person + 1
            elif rps_result[1]['rps']=='scissors': text = 'Rock wins'   ; winner = 0; left_person = left_person + 1
        elif rps_result[0]['rps']=='paper':
            if rps_result[1]['rps']=='rock'     : text = 'Paper wins'  ; winner = 0; left_person = left_person + 1
            elif rps_result[1]['rps']=='paper'  : text = 'Tie' ; tie = True
            elif rps_result[1]['rps']=='scissors': text = 'Scissors wins'; winner = 1; right_person = right_person + 1
        elif rps_result[0]['rps']=='scissors':
            if rps_result[1]['rps']=='rock'     : text = 'Rock wins'   ; winner = 1; right_person = right_person + 1
            elif rps_result[1]['rps']=='paper'  : text = 'Scissors wins'; winner = 0; left_person =left_person + 1
            elif rps_result[1]['rps']=='scissors': text = 'Tie' ; tie = True

          # for idx in range(len(rps_result)):
          #         # if i == 0:
          #     cv2.putText(img_org, text=rps_result[idx]['rps'].upper(), org=(int(rps_result[idx]['org'][0] / 0.4) , 100), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
        height = int(img_org.shape[1]/2)
        wight = int(img_org.shape[0])
        cv2.line(img_org, (height,10), (height, wight), (0,255,0), 3)

        if winner is not None:
              # cv2.putText(img_org, text='Winner'q, org=(int(rps_result[winner]['org'][0] / 0.4), int(100 + 70)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(0, 255, 0), thickness=3)
              
          if winner == 0:
            cv2.putText(img_org, text=text, org=(int(img_org.shape[1] / 6.5), 100), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(200, 0, 100), thickness=3)
          else:
            cv2.putText(img_org, text=text, org=(int(img_org.shape[1] / 1.8), 100), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(200, 0, 100), thickness=3)
            cv2.putText(img_org, text=cls_text, org=(int(img_org.shape[1] / 6.5), 270), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(0, 0, 255), thickness=3)

        elif tie:
            cv2.putText(img_org, text=text, org=(int(img_org.shape[1] / 2) - 25, 120), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size * 1.5, color=(0, 0, 255), thickness=3)
            cv2.putText(img_org, text=cls_text, org=(int(img_org.shape[1] / 6.5), 270), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(0, 0, 255), thickness=3)
            #cv2.imshow('Game', img_org)
            #key = cv2.waitKey()


        Score = "Left_Person  : " + str(left_person)  + "  " + "Right_Person : " + str(right_person)
        img_org = cv2.resize(img_org, None, fx=1.0, fy=1.0, interpolation=cv2.INTER_AREA)
          
        cv2.putText(img_org, Score, (40,60), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2)
        cv2.imshow('Game', img_org)
        key = cv2.waitKey()  

        if key == ord('r') or key == ord('R'):
            save_dir = result_dic['success']
            csv_path = os.path.join(save_dir, "result.csv")
            if os.path.exists(csv_path):
                result_log = pd.read_csv(csv_path, index_col=0)
            else:
                result_log = pd.DataFrame([], columns=columns)
                result_log.loc[len(result_log)] = [rps_result[0]['rps'], rps_result[1]['rps'], "s"]
        elif key == ord('f') or key == ord('F'):
            save_dir = result_dic['fail']
            csv_path = os.path.join(save_dir, "result.csv")
            if os.path.exists(csv_path):
                result_log = pd.read_csv(csv_path, index_col=0)
            else:
                result_log = pd.DataFrame([], columns=columns)
                result_log.loc[len(result_log)] = [rps_result[0]['rps'], rps_result[1]['rps'], "f"]
        else:
            save_dir = result_dic['no_cls']
            csv_path = os.path.join(save_dir, "result.csv")
            if os.path.exists(csv_path):
                result_log = pd.read_csv(csv_path, index_col=0)
            else:
                result_log = pd.DataFrame([], columns=columns)
                result_log.loc[len(result_log)] = [rps_result[0]['rps'], rps_result[1]['rps'], "n"]

        result_log.to_csv(csv_path) 
        cv2.imwrite(os.path.join(save_dir, str(len(result_log) - 1) + ".png"), img) 
    else:
      height = int(img_org.shape[1]/2)
      wight = int(img_org.shape[0])
      img_org = cv2.resize(img_org, None, fx=1.0, fy=1.0, interpolation=cv2.INTER_AREA)
      cv2.line(img_org, (height,10), (height, wight), (0,255,0), 3)
      cv2.putText(img_org, "Make the correct motion.", org=(int(img_org.shape[1] / 6), 60), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(0, 0, 255), thickness=3)
      cv2.imshow('Game', img_org)
      cv2.waitKey()

    #hands not 2
  else:
    height = int(img_org.shape[1]/2)
    wight = int(img_org.shape[0])
    img_org = cv2.resize(img_org, None, fx=1.0, fy=1.0, interpolation=cv2.INTER_AREA)
    cv2.line(img_org, (height,0), (height, wight), (100,0,0), 3)
    cv2.putText(img_org, "No hands detected", org=(int(img_org.shape[1] / 4), 70), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(0, 0, 255), thickness=3)
    cv2.putText(img_org, "press s to restart", org=(int(img_org.shape[1] / 4), 120), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=font_size, color=(0, 0, 255), thickness=3)
    cv2.imshow('Game', img_org)
    cv2.waitKey()
    continue
  
  print(len(rps_result))


  cv2.destroyAllWindows()

  if cv2.waitKey(delay) == ord('q'):
    stop = True
    break
  if stop == True:
    break
   
